# Deuna! — Data Platform & Security Foundation (Terraform)

Repositorio modular de Terraform para aprovisionar:
- **KMS:** Llave simétrica con rotación anual automática y política de mínimo privilegio.
- **S3:** Bucket financiero privado, cifrado con KMS, versionado, lifecycle y bloqueo de acceso público.
- **Aurora PostgreSQL:** Clúster en subnets privadas, cifrado con KMS, security group restringido, backups y Performance Insights / monitoreo habilitados.
- **Secrets Manager:** Credenciales `pgadmin` (`username` + `password`) cifradas con KMS, con rotación automática y resource policy restringida.

## Validaciones recomendadas antes de `apply`
1. `terraform fmt -check -recursive`
2. `terraform validate`
3. `checkov -d .` (o `trivy config .`)
4. `gitleaks detect --source .`
5. `terraform plan -out=tfplan`
