provider "aws" {
  region = var.aws_region
}

locals {
  common_tags = {
    Environment = "prod"
    Project     = "deuna-data-platform"
  }
}

module "kms_data" {
  source = "../../modules/kms"

  name                        = "deuna-prod-data-key"
  description                 = "Llave simétrica KMS para S3, Aurora y Secrets Manager en prod"
  authorized_principal_arns = var.kms_authorized_arns
  tags                        = local.common_tags
}

module "financial_bucket" {
  source = "../../modules/s3"

  bucket_name = "deuna-prod-financial-data"
  kms_key_arn = module.kms_data.key_arn
  tags        = local.common_tags
}

module "aurora_pg" {
  source = "../../modules/aurora"

  cluster_identifier           = "deuna-prod-aurora-pg"
  database_name                = "deuna_prod"
  master_username              = var.pgadmin_username
  master_password              = var.pgadmin_password
  vpc_id                       = var.vpc_id
  vpc_cidr                     = var.vpc_cidr
  private_subnet_ids           = var.private_subnet_ids
  allowed_security_group_ids   = var.allowed_security_group_ids
  kms_key_arn                  = module.kms_data.key_arn
  enhanced_monitoring_role_arn = var.enhanced_monitoring_role_arn
  tags                         = local.common_tags
}

module "pgadmin_secret" {
  source = "../../modules/secrets"

  secret_name                 = "deuna/prod/aurora/pgadmin"
  environment                 = "prod"
  pgadmin_username            = var.pgadmin_username
  pgadmin_password            = var.pgadmin_password
  kms_key_arn                 = module.kms_data.key_arn
  rotation_lambda_arn         = var.rotation_lambda_arn
  authorized_principal_arns = var.secret_authorized_arns
  tags                        = local.common_tags
}