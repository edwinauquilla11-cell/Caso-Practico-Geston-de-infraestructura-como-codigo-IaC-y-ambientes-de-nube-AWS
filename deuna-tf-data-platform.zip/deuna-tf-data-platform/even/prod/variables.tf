variable "aws_region" {
  type    = string
  default = "us-east-1"
}

variable "vpc_id" {
  type = string
}

variable "vpc_cidr" {
  type = string
}

variable "private_subnet_ids" {
  type = list(string)
}

variable "allowed_security_group_ids" {
  type = list(string)
}

variable "kms_authorized_arns" {
  type = list(string)
}

variable "secret_authorized_arns" {
  type = list(string)
}

variable "enhanced_monitoring_role_arn" {
  type = string
}

variable "rotation_lambda_arn" {
  type = string
}

variable "pgadmin_username" {
  type    = string
  default = "pgadmin"
}

variable "pgadmin_password" {
  type      = string
  sensitive = true
}