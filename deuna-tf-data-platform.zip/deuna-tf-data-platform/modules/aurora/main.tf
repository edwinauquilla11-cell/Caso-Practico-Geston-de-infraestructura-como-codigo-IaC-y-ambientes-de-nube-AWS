resource "aws_db_subnet_group" "private" {
  name       = "${var.cluster_identifier}-private-subnets"
  subnet_ids = var.private_subnet_ids

  tags = merge(var.tags, {
    Name      = "${var.cluster_identifier}-private-subnets"
    ManagedBy = "terraform"
  })
}

resource "aws_security_group" "aurora" {
  name        = "${var.cluster_identifier}-sg"
  description = "Acceso restringido a PostgreSQL en subnets privadas"
  vpc_id      = var.vpc_id

  ingress {
    description     = "PostgreSQL desde security groups autorizados"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = var.allowed_security_group_ids
  }

  egress {
    description = "Salida controlada dentro de VPC"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = [var.vpc_cidr]
  }

  tags = merge(var.tags, {
    Name      = "${var.cluster_identifier}-sg"
    ManagedBy = "terraform"
  })
}

resource "aws_rds_cluster" "this" {
  cluster_identifier              = var.cluster_identifier
  engine                          = "aurora-postgresql"
  engine_version                  = var.engine_version
  database_name                   = var.database_name
  master_username                 = var.master_username
  master_password                 = var.master_password
  db_subnet_group_name            = aws_db_subnet_group.private.name
  vpc_security_group_ids          = [aws_security_group.aurora.id]
  storage_encrypted               = true
  kms_key_id                      = var.kms_key_arn
  backup_retention_period         = var.backup_retention_days
  preferred_backup_window         = var.preferred_backup_window
  preferred_maintenance_window    = var.preferred_maintenance_window
  deletion_protection             = var.deletion_protection
  skip_final_snapshot             = false
  final_snapshot_identifier       = "${var.cluster_identifier}-final-snap"
  enabled_cloudwatch_logs_exports = ["postgresql"]

  tags = merge(var.tags, {
    Name           = var.cluster_identifier
    DataDomain     = "financial"
    Classification = "restricted"
    ManagedBy      = "terraform"
  })
}

resource "aws_rds_cluster_instance" "instances" {
  count                           = var.instance_count
  identifier                      = "${var.cluster_identifier}-${count.index + 1}"
  cluster_identifier              = aws_rds_cluster.this.id
  instance_class                  = var.instance_class
  engine                          = aws_rds_cluster.this.engine
  engine_version                  = aws_rds_cluster.this.engine_version
  publicly_accessible             = false
  performance_insights_enabled    = true
  performance_insights_kms_key_id = var.kms_key_arn
  monitoring_interval             = 60
  monitoring_role_arn             = var.enhanced_monitoring_role_arn

  tags = merge(var.tags, {
    Name      = "${var.cluster_identifier}-${count.index + 1}"
    ManagedBy = "terraform"
  })
}