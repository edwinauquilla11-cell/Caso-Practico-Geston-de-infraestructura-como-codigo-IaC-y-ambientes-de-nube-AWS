variable "cluster_identifier" {
  type        = string
  description = "Identificador del clúster Aurora PostgreSQL"
}

variable "engine_version" {
  type        = string
  description = "Versión del motor Aurora PostgreSQL"
  default     = "15.6"
}

variable "database_name" {
  type        = string
  description = "Nombre de la base de datos inicial"
}

variable "master_username" {
  type        = string
  description = "Usuario administrador principal (pgadmin)"
}

variable "master_password" {
  type        = string
  description = "Contraseña inicial del usuario administrador"
  sensitive   = true
}

variable "vpc_id" {
  type        = string
  description = "ID de la VPC"
}

variable "vpc_cidr" {
  type        = string
  description = "CIDR de la VPC para egress controlado"
}

variable "private_subnet_ids" {
  type        = list(string)
  description = "IDs de subnets privadas"
}

variable "allowed_security_group_ids" {
  type        = list(string)
  description = "Security groups autorizados a conectarse al puerto 5432"
}

variable "kms_key_arn" {
  type        = string
  description = "ARN de la llave KMS para cifrado"
}

variable "enhanced_monitoring_role_arn" {
  type        = string
  description = "ARN del rol IAM para Enhanced Monitoring"
}

variable "instance_count" {
  type        = number
  description = "Cantidad de instancias en el clúster"
  default     = 2
}

variable "instance_class" {
  type        = string
  description = "Clase de instancia RDS"
  default     = "db.r6g.large"
}

variable "backup_retention_days" {
  type        = number
  description = "Días de retención de backups automatizados"
  default     = 14
}

variable "preferred_backup_window" {
  type        = string
  description = "Ventana horaria de backup en UTC"
  default     = "03:00-04:00"
}

variable "preferred_maintenance_window" {
  type        = string
  description = "Ventana horaria de mantenimiento en UTC"
  default     = "sun:04:00-sun:05:00"
}

variable "deletion_protection" {
  type        = bool
  description = "Protección contra borrado accidental"
  default     = true
}

variable "tags" {
  type        = map(string)
  description = "Etiquetas comunes del entorno"
  default     = {}
}