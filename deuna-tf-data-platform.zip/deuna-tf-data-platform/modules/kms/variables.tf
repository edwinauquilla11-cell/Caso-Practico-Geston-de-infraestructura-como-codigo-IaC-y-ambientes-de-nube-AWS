variable "name" {
  type        = string
  description = "Nombre base de la llave KMS y su alias"
}

variable "description" {
  type        = string
  description = "Descripción de la llave KMS"
}

variable "deletion_window_in_days" {
  type        = number
  description = "Días de espera antes de eliminar la llave"
  default     = 30
}

variable "authorized_principal_arns" {
  type        = list(string)
  description = "ARNs de roles/usuarios autorizados a usar la llave KMS"
}

variable "tags" {
  type        = map(string)
  description = "Etiquetas comunes del entorno"
  default     = {}
}