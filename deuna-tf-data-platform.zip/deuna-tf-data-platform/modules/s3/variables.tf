variable "bucket_name" {
  type        = string
  description = "Nombre único global del bucket S3"
}

variable "kms_key_arn" {
  type        = string
  description = "ARN de la llave KMS para cifrado"
}

variable "glacier_transition_days" {
  type        = number
  description = "Días para mover objetos actuales a Glacier Instant Retrieval"
  default     = 90
}

variable "noncurrent_glacier_days" {
  type        = number
  description = "Días para mover versiones anteriores a Glacier Instant Retrieval"
  default     = 30
}

variable "noncurrent_expiration_days" {
  type        = number
  description = "Días para expirar versiones anteriores"
  default     = 365
}

variable "tags" {
  type        = map(string)
  description = "Etiquetas comunes del entorno"
  default     = {}
}