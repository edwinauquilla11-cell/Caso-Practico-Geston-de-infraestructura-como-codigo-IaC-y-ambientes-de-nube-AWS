resource "aws_secretsmanager_secret" "pgadmin" {
  name                    = var.secret_name
  description             = "Credenciales pgadmin para cluster Aurora PostgreSQL"
  kms_key_id              = var.kms_key_arn
  recovery_window_in_days = var.recovery_window_in_days

  tags = merge(var.tags, {
    Name           = var.secret_name
    DataDomain     = "financial"
    Classification = "restricted"
    ManagedBy      = "terraform"
  })
}

resource "aws_secretsmanager_secret_version" "pgadmin" {
  secret_id = aws_secretsmanager_secret.pgadmin.id
  secret_string = jsonencode({
    username = var.pgadmin_username
    password = var.pgadmin_password
  })

  lifecycle {
    ignore_changes = [secret_string]
  }
}

resource "aws_secretsmanager_secret_rotation" "pgadmin" {
  secret_id           = aws_secretsmanager_secret.pgadmin.id
  rotation_lambda_arn = var.rotation_lambda_arn

  rotation_rules {
    automatically_after_days = var.rotation_days
  }
}

resource "aws_secretsmanager_secret_policy" "pgadmin" {
  secret_arn = aws_secretsmanager_secret.pgadmin.arn

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowAuthorizedRolesReadSecret"
        Effect = "Allow"
        Principal = {
          AWS = var.authorized_principal_arns
        }
        Action = [
          "secretsmanager:GetSecretValue",
          "secretsmanager:DescribeSecret"
        ]
        Resource = "*"
        Condition = {
          StringEquals = {
            "aws:PrincipalTag/Environment" = var.environment
          }
        }
      }
    ]
  })
}