output "secret_arn" {
  value = aws_secretsmanager_secret.pgadmin.arn
}

output "secret_name" {
  value = aws_secretsmanager_secret.pgadmin.name
}