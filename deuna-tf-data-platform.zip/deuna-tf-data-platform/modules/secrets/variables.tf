variable "secret_name" {
  type        = string
  description = "Nombre del secreto en Secrets Manager"
}

variable "environment" {
  type        = string
  description = "Entorno (dev, staging, prod)"
}

variable "pgadmin_username" {
  type        = string
  description = "Usuario pgadmin"
}

variable "pgadmin_password" {
  type        = string
  description = "Contraseña inicial de pgadmin"
  sensitive   = true
}

variable "kms_key_arn" {
  type        = string
  description = "ARN de la llave KMS para cifrado"
}

variable "rotation_lambda_arn" {
  type        = string
  description = "ARN de la función Lambda de rotación"
}

variable "rotation_days" {
  type        = number
  description = "Frecuencia de rotación automática en días"
  default     = 30
}

variable "recovery_window_in_days" {
  type        = number
  description = "Ventana de recuperación al eliminar el secreto"
  default     = 30
}

variable "authorized_principal_arns" {
  type        = list(string)
  description = "ARNs de roles autorizados a leer el secreto"
}

variable "tags" {
  type        = map(string)
  description = "Etiquetas comunes del entorno"
  default     = {}
}